import { Component, OnInit } from '@angular/core';
import { Ingredient } from '../shared/ingredients.model';

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit {
ingredients:Ingredient[]=[
  new Ingredient('Rice',7),
  new Ingredient('Tomatoes',15)
];
  constructor() { }

  ngOnInit() {
  }
  
  addIngredientToList(ingredient: Ingredient){
    this.ingredients.push(ingredient);
  }
}
